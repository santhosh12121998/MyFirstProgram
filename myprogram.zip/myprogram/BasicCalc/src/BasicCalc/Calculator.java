package BasicCalc;

import java.util.Scanner;

public class Calculator {
	public static void main(String []args) {
		System.out.println("enter the first number: ");
		Scanner calculate=new Scanner(System.in);
		int num1=calculate.nextInt();
		System.out.println("enter the second number: ");
		int num2=calculate.nextInt();
		calculate.close();
		Add.addition(num1, num2);
		Multiply.Multiplication(num1, num2);
		Sub.subraction(num1, num2);
		Divide.divsion(num1, num2);
		}

}
