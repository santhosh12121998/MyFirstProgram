package BasicCalc;

public class Add {
	public static void addition(int a,int b){
		System.out.println("addition of two number is: "+(a+b));
		}
}
