package BasicCalc;

public class Multiply {
	public static void Multiplication(int a,int b){
		System.out.println("Multiplication of two number is: "+(a*b));
		}

}
