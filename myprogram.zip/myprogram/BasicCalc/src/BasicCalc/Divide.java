package BasicCalc;

public class Divide {
	public static void divsion(double a,double b){
		System.out.println("divsion of two number is: "+(a/b));
		}

}
