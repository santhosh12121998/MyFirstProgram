package BasicCalc;

public class Sub {
	public static void subraction(int a,int b){
		System.out.println("subraction of two number is: "+(a-b));
		}

}
